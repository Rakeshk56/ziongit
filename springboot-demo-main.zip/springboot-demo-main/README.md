# springboot-demo

# Build the jar
$ mvn clean package

# Run the jar

$ java -jar target/jar-demo-app-1.0.0.jar


